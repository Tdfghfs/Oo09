# دليل النشر المفصل - Deployment Guide

## نظرة عامة

هذا الدليل يوضح كيفية نشر تطبيق واجهة الترمنال الويب على منصات الاستضافة المختلفة، مع تعليمات مفصلة لكل منصة.

## الملفات المطلوبة للنشر

تأكد من وجود الملفات التالية في مجلد المشروع:

```
web-terminal/
├── app.py              # التطبيق الرئيسي
├── requirements.txt    # المتطلبات
├── Dockerfile         # ملف Docker
├── README.md          # دليل المشروع
└── uploads/           # مجلد الملفات (سيتم إنشاؤه تلقائياً)
```

## 1. النشر على Render (مُوصى به)

### المميزات
- خطة مجانية دائمة
- نشر تلقائي من Git
- دعم كامل لـ Python
- SSL مجاني
- لا ينام التطبيق (Always-On)

### خطوات النشر

#### الخطوة 1: إعداد المستودع
```bash
# إنشاء مستودع Git جديد
git init
git add .
git commit -m "Initial commit"

# رفع إلى GitHub
git remote add origin <your-github-repo-url>
git push -u origin main
```

#### الخطوة 2: إنشاء حساب Render
1. اذهب إلى [render.com](https://render.com)
2. أنشئ حساب جديد أو سجل دخول
3. ربط حساب GitHub

#### الخطوة 3: إنشاء Web Service
1. النقر على "New +"
2. اختيار "Web Service"
3. ربط المستودع من GitHub
4. تعيين الإعدادات:
   - **Name**: `web-terminal` (أو أي اسم تريده)
   - **Environment**: `Python 3`
   - **Build Command**: `pip install -r requirements.txt`
   - **Start Command**: `gunicorn --bind 0.0.0.0:$PORT --workers 1 --timeout 120 app:app`

#### الخطوة 4: النشر
1. النقر على "Create Web Service"
2. انتظار اكتمال البناء (5-10 دقائق)
3. الحصول على الرابط العام

### إعدادات متقدمة لـ Render

#### متغيرات البيئة
```
PYTHONUNBUFFERED=1
PYTHONDONTWRITEBYTECODE=1
```

#### ملف render.yaml (اختياري)
```yaml
services:
  - type: web
    name: web-terminal
    env: python
    buildCommand: pip install -r requirements.txt
    startCommand: gunicorn --bind 0.0.0.0:$PORT --workers 1 --timeout 120 app:app
    envVars:
      - key: PYTHONUNBUFFERED
        value: 1
```

## 2. النشر على Railway

### المميزات
- $5 رصيد مجاني
- نشر سريع
- دعم Docker
- قاعدة بيانات مجانية

### خطوات النشر

#### الخطوة 1: تثبيت Railway CLI
```bash
npm install -g @railway/cli
```

#### الخطوة 2: تسجيل الدخول
```bash
railway login
```

#### الخطوة 3: النشر
```bash
# في مجلد المشروع
railway init
railway up
```

#### الخطوة 4: ربط النطاق
```bash
railway domain
```

## 3. النشر على Fly.io

### المميزات
- 300 دقيقة بناء مجانية
- VM صغيرة مجانية
- انتشار عالمي
- دعم Docker ممتاز

### خطوات النشر

#### الخطوة 1: تثبيت flyctl
```bash
# macOS
brew install flyctl

# Linux
curl -L https://fly.io/install.sh | sh

# Windows
iwr https://fly.io/install.ps1 -useb | iex
```

#### الخطوة 2: تسجيل الدخول
```bash
fly auth signup
# أو
fly auth login
```

#### الخطوة 3: إنشاء التطبيق
```bash
fly launch
```

#### الخطوة 4: النشر
```bash
fly deploy
```

### ملف fly.toml
```toml
app = "web-terminal"
primary_region = "fra"

[build]

[http_service]
  internal_port = 5000
  force_https = true
  auto_stop_machines = true
  auto_start_machines = true
  min_machines_running = 0
  processes = ["app"]

[[vm]]
  cpu_kind = "shared"
  cpus = 1
  memory_mb = 256
```

## 4. النشر على Replit

### المميزات
- تطوير ونشر من المتصفح
- مجاني للمشاريع العامة
- بيئة تطوير متكاملة

### خطوات النشر

#### الخطوة 1: إنشاء Repl جديد
1. اذهب إلى [replit.com](https://replit.com)
2. النقر على "Create Repl"
3. اختيار "Python"
4. تسمية المشروع

#### الخطوة 2: رفع الملفات
1. رفع جميع ملفات المشروع
2. التأكد من وجود `requirements.txt`

#### الخطوة 3: تشغيل التطبيق
```python
# في main.py
import subprocess
import sys

# تثبيت المتطلبات
subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])

# تشغيل التطبيق
exec(open('app.py').read())
```

#### الخطوة 4: النشر
1. النقر على "Run"
2. الحصول على الرابط العام

## 5. النشر على Heroku

### المميزات
- منصة مشهورة
- دعم ممتاز لـ Python
- إضافات متنوعة

### خطوات النشر

#### الخطوة 1: تثبيت Heroku CLI
```bash
# تحميل من heroku.com/cli
```

#### الخطوة 2: تسجيل الدخول
```bash
heroku login
```

#### الخطوة 3: إنشاء التطبيق
```bash
heroku create web-terminal-app
```

#### الخطوة 4: إضافة ملف Procfile
```
web: gunicorn --bind 0.0.0.0:$PORT app:app
```

#### الخطوة 5: النشر
```bash
git add .
git commit -m "Deploy to Heroku"
git push heroku main
```

## 6. النشر باستخدام Docker

### إنشاء صورة Docker
```bash
docker build -t web-terminal .
```

### تشغيل محلي
```bash
docker run -p 5000:5000 web-terminal
```

### النشر على Docker Hub
```bash
docker tag web-terminal username/web-terminal
docker push username/web-terminal
```

## إعدادات الأمان للإنتاج

### 1. متغيرات البيئة
```python
import os

# في app.py
SECRET_KEY = os.environ.get('SECRET_KEY', 'your-secret-key')
DEBUG = os.environ.get('DEBUG', 'False').lower() == 'true'
```

### 2. تحديد المنافذ المسموحة
```python
ALLOWED_HOSTS = os.environ.get('ALLOWED_HOSTS', 'localhost').split(',')
```

### 3. تشفير HTTPS
- معظم منصات الاستضافة توفر SSL مجاني
- تأكد من تفعيل HTTPS

### 4. حدود الموارد
```python
# في app.py
MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB
UPLOAD_TIMEOUT = 30  # 30 seconds
```

## مراقبة التطبيق

### 1. السجلات (Logs)
```bash
# Render
render logs

# Railway
railway logs

# Fly.io
fly logs

# Heroku
heroku logs --tail
```

### 2. مراقبة الأداء
- استخدام أدوات المراقبة المدمجة
- تتبع استهلاك الذاكرة والمعالج
- مراقبة أوقات الاستجابة

## استكشاف أخطاء النشر

### مشاكل شائعة

#### 1. خطأ في بناء التطبيق
```bash
# التحقق من requirements.txt
pip install -r requirements.txt

# التحقق من إصدار Python
python --version
```

#### 2. خطأ في تشغيل التطبيق
```bash
# اختبار محلي
python app.py

# اختبار gunicorn
gunicorn app:app
```

#### 3. مشاكل المنافذ
```python
# التأكد من استخدام متغير PORT
port = int(os.environ.get('PORT', 5000))
app.run(host='0.0.0.0', port=port)
```

#### 4. مشاكل الذاكرة
- تقليل عدد العمليات المتوازية
- تحسين استهلاك الذاكرة
- استخدام خوادم أقوى

## نصائح للأداء الأمثل

### 1. تحسين Gunicorn
```bash
gunicorn --bind 0.0.0.0:$PORT \
         --workers 1 \
         --timeout 120 \
         --max-requests 1000 \
         --max-requests-jitter 100 \
         app:app
```

### 2. ضغط الاستجابات
```python
from flask_compress import Compress
Compress(app)
```

### 3. تخزين مؤقت
```python
from flask_caching import Cache
cache = Cache(app)
```

## الخلاصة

اختر المنصة التي تناسب احتياجاتك:

- **Render**: الأفضل للمشاريع المجانية الدائمة
- **Railway**: سريع وسهل مع رصيد مجاني
- **Fly.io**: للمشاريع التي تحتاج انتشار عالمي
- **Replit**: للتطوير السريع والتجريب
- **Heroku**: للمشاريع التجارية

جميع هذه المنصات تدعم التطبيق بشكل ممتاز، والاختيار يعتمد على متطلباتك الخاصة.

